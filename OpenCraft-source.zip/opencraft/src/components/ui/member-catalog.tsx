import { useId } from 'react';
import { Heart, Plus, Search, X } from 'lucide-react';
import { categories } from '@/lib/catalog';
import { setMarketFilters, addToCart, toggleFavorite } from '@/commerce.js';
import { useCatalogResults } from '@/lib/marketplace-api';
import { useMarket } from '@/lib/use-market';
import AnimatedBackground from './animated-tabs';
const types = [{ id: 'all', label: 'ทั้งหมด' }, { id: 'physical', label: 'สินค้า' }, { id: 'digital', label: 'ดิจิทัล' }, { id: 'service', label: 'บริการ' }];

export default function MemberCatalog({ publicView = false, preferredCategories = [] }: { publicView?: boolean; preferredCategories?: string[] }) {
  const market = useMarket(), unique = useId();
  const query = useCatalogResults(market);
  const results = [...(query.data?.products || [])];
  if (market.sort === 'recommended' && preferredCategories.length) results.sort((a, b) => Number(preferredCategories.includes(b.cat)) - Number(preferredCategories.includes(a.cat)));
  const shown = publicView ? results.slice(0, market.limit) : results;
  const filtered = market.query || market.category !== 'all' || market.filter !== 'all';
  const id = publicView ? 'public-catalog' : 'member-catalog';
  return <section id={id} className={`member-catalog ${publicView ? 'is-public' : ''}`} aria-labelledby={`${id}-title`}>
    <div className="member-catalog-heading"><div><h2 id={`${id}-title`}>{publicView ? 'เริ่มจากสิ่งที่คุณกำลังมองหา' : 'ค้นหาสิ่งที่ใช่'}</h2><p>{publicView ? 'ค้นหาและดูรายละเอียดได้ก่อนสมัครสมาชิก' : 'สินค้า งานดิจิทัล และบริการ ในที่เดียว'}</p></div><label className="member-sort"><span className="visually-hidden">เรียงสินค้า</span><select aria-label="เรียงสินค้า" value={market.sort} onChange={event => setMarketFilters({ sort: event.target.value })}><option value="recommended">แนะนำ</option><option value="newest">มาใหม่</option><option value="price-asc">ราคาต่ำไปสูง</option><option value="price-desc">ราคาสูงไปต่ำ</option></select></label></div>
    <label className="member-search"><Search size={20}/><input type="search" maxLength={200} placeholder="ค้นหาสินค้า บริการ หรือไอเดีย" aria-label="ค้นหาสินค้าและบริการ" value={market.query} onChange={event => setMarketFilters({ query: event.target.value, limit: 24 })}/>{market.query && <button onClick={() => setMarketFilters({ query: '' })} aria-label="ล้างคำค้นหา"><X size={17}/></button>}</label>
    <div className="catalog-type-tabs" role="tablist" aria-label="ประเภทที่ต้องการค้นหา" onKeyDown={event => { if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) { event.preventDefault(); const nodes = [...event.currentTarget.querySelectorAll<HTMLButtonElement>('[role=tab]')], index = nodes.indexOf(document.activeElement as HTMLButtonElement); const next = event.key === 'Home' ? 0 : event.key === 'End' ? nodes.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + nodes.length) % nodes.length; nodes[next]?.click(); nodes[next]?.focus(); } }}>
      <AnimatedBackground value={market.filter} onValueChange={value => { if (value) setMarketFilters({ filter: value, limit: 24 }); }} className="catalog-tab-background" transition={{ type: 'spring', bounce: .15, duration: .35 }}>{types.map(type => <button key={type.id} data-id={type.id} role="tab" id={`${unique}-${type.id}`} aria-controls={`${id}-results`} tabIndex={market.filter === type.id ? 0 : -1}>{type.label}</button>)}</AnimatedBackground>
    </div>
    <div className="member-category-list" aria-label="หมวดหมู่สินค้า">{[categories[categories.length - 1], ...categories.slice(0, -1)].map(category => <button key={category.id} aria-pressed={market.category === category.id} onClick={() => setMarketFilters({ category: category.id, limit: 24 })}>{category.id === 'all' ? 'ทุกหมวด' : category.name}</button>)}</div>
    {filtered && !query.loading && !query.error && <div className="member-filter-status" role="status"><span>พบ {results.length} รายการ</span><button onClick={() => setMarketFilters({ query: '', category: 'all', filter: 'all' })}>ล้างตัวกรอง<X size={13}/></button></div>}
    <div id={`${id}-results`} role="tabpanel" aria-labelledby={`${unique}-${market.filter}`} tabIndex={0}>
    {query.loading ? <div className="member-empty" role="status"><p>กำลังค้นหาสินค้า…</p></div> : query.error ? <div className="member-empty" role="alert"><h3>ยังโหลดสินค้าไม่ได้</h3><p>กรุณาลองเชื่อมต่ออีกครั้ง</p><button onClick={query.retry}>ลองโหลดสินค้าอีกครั้ง</button></div> : shown.length ? <div className="member-product-grid">{shown.map(item => <article className="member-product" key={item.id}><div className="member-product-visual"><button className="member-product-open" aria-label={`ดู ${item.title}`} onClick={() => document.dispatchEvent(new CustomEvent('opencraft:open-product', { detail: { id: item.id } }))}><img src={`/assets/${item.image}`} alt={item.title} width="900" height="670" loading="lazy"/></button>{!publicView && <button className={`member-save ${market.favorites.includes(item.id) ? 'is-saved' : ''}`} aria-label={`บันทึก ${item.title}`} aria-pressed={market.favorites.includes(item.id)} onClick={() => toggleFavorite(item.id)}><Heart size={17}/></button>}</div><div className="member-product-caption"><div><button onClick={() => document.dispatchEvent(new CustomEvent('opencraft:open-product', { detail: { id: item.id } }))}>{item.title}</button><span>{item.type === 'service' ? 'เริ่ม ' : ''}฿{item.price.toLocaleString('th-TH')}</span></div>{!publicView && <button className="member-add" onClick={() => addToCart(item.id)} aria-label={`เพิ่ม ${item.title} ลงตะกร้า`}><Plus size={18}/></button>}</div></article>)}</div> : <div className="member-empty"><Search size={26}/><h3>ยังไม่เจอสิ่งที่คุณมองหา</h3><p>ลองใช้คำค้นหาหรือหมวดหมู่อื่น</p><button onClick={() => setMarketFilters({ query: '', category: 'all', filter: 'all' })}>ดูสินค้าทั้งหมด</button></div>}
    </div>
    {publicView && results.length > shown.length && <button className="landing-catalog-more" onClick={() => setMarketFilters({ limit: 24 })}>ดูสินค้าเพิ่มเติม</button>}
    <p className="member-catalog-note">รายการสินค้าและร้านเป็นตัวอย่าง ยังไม่เปิดรับคำสั่งซื้อจริง</p>
  </section>;
}
