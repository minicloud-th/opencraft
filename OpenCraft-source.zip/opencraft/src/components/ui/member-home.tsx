import { useEffect, useRef, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowLeft, ArrowRight, ArrowUpRight, X } from 'lucide-react';
import type { User } from 'firebase/auth';
import { products } from '@/lib/catalog';
import { navigateAuth } from '@/lib/auth-navigation';
import MemberCatalog from './member-catalog';
import ProfileDropdown from './profile-dropdown';
import { useMarket } from '@/lib/use-market';
import { MenuBar, type MenuBarKey } from './animated-menu-bar';
import type { MemberIdentity, MemberProfile } from '@/lib/member-profile';
import { memberPaths, type MemberPage } from '@/lib/member-navigation';
import MemberPages from './member-pages';
import { pendingSecurity, useShowcase, type ShowcaseResult } from '@/lib/showcase';
import '@/profile-social.css';
import '@/appearance.css';

type MemberHomeProps = {
  user: MemberIdentity; page?: MemberPage; preferences?: MemberProfile; notice?: string; issue?: string; busy?: boolean;
  authUser?: User | null; previewShowcase?: ShowcaseResult;
  onSignOut: () => void; onBrowse?: () => void; onProfile?: () => void; onDismiss?: () => void; onNavigate?: (page: MemberPage) => void; onVerify?: () => void;
};
const featured = ['headphones', 'uikit', 'brand', 'website', 'sneaker', 'controller'].map(id => products.find(product => product.id === id)!);
const categoryNames: Record<string, string> = { gadget: 'ไอที', digital: 'ดิจิทัล', design: 'ออกแบบ', service: 'บริการ', fashion: 'แฟชั่น', gaming: 'เกม' };
const memberMenuItems: readonly MenuBarKey[] = ['dashboard', 'favorites', 'cart', 'topup', 'seller', 'notifications', 'help', 'security'];
const memberMenuLabels = { dashboard: 'หน้าหลัก', favorites: 'รายการที่บันทึก', cart: 'ตะกร้า', topup: 'เติมเงิน', seller: 'ร้านค้าของฉัน', notifications: 'การแจ้งเตือน', settings: 'ตั้งค่า', help: 'ช่วยเหลือ', security: 'ความปลอดภัย' };

export default function MemberHome({ user, page = 'dashboard', preferences, authUser, previewShowcase, onSignOut, onBrowse, onProfile, onDismiss, onNavigate, onVerify, notice, issue, busy }: MemberHomeProps) {
  const [active, setActive] = useState(0), [width, setWidth] = useState(640);
  const deckRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLButtonElement | null)[]>([]), keyboardMove = useRef(false);
  const reduce = useReducedMotion();
  const cardWidth = Math.min(290, Math.max(190, width * .48));
  const spacing = Math.max(8, Math.min(58, (width - cardWidth) / 5));
  const market = useMarket();
  const showcase = useShowcase(authUser, previewShowcase);
  const security = showcase.data?.security || pendingSecurity;
  const memberUser: MemberIdentity = { ...user, displayName: showcase.data?.showcase.displayName || user.displayName, photoURL: showcase.data?.showcase.photoURL || user.photoURL };
  const secure = security.emailVerified && security.mfaEnabled;
  const browse = onBrowse || (() => document.querySelector('#member-catalog')?.scrollIntoView({ behavior: reduce ? 'instant' : 'smooth', block: 'start' }));
  useEffect(() => {
    const open = () => document.querySelector('#member-catalog')?.scrollIntoView({ behavior: 'instant', block: 'start' });
    document.addEventListener('opencraft:browse', open);
    if (page === 'dashboard' && location.hash === '#discover') open();
    return () => document.removeEventListener('opencraft:browse', open);
  }, [page]);
  const goPage = (next: MemberPage) => {
    if (next === 'account' && onProfile) { onProfile(); return; }
    if (onNavigate) onNavigate(next); else navigateAuth(memberPaths[next]);
  };
  const selectTool = (key: MenuBarKey) => { if (key === 'dashboard') setActive(0); goPage(key === 'settings' ? 'account' : key); };
  const shift = (direction: number) => setActive(index => (index + direction + featured.length) % featured.length);
  useEffect(() => { if (keyboardMove.current) { cardRefs.current[active]?.focus({ preventScroll: true }); keyboardMove.current = false; } }, [active]);
  useEffect(() => {
    const node = deckRef.current; if (!node) return;
    const observer = new ResizeObserver(([entry]) => setWidth(entry.contentRect.width)); observer.observe(node);
    return () => observer.disconnect();
  }, [page]);
  return <div className="member-shell">
    <aside className="member-rail" aria-label="เมนูสมาชิก">
      <a className="member-brand" href="/" onClick={event => { event.preventDefault(); navigateAuth('/'); }} aria-label="OpenCraft หน้าแนะนำ"><img src="/assets/opencraft-symbol.png" alt="" width="36" height="36"/></a>
      <div className="member-side-menu"><MenuBar orientation="vertical" active={page === 'account' || page === 'profile' || page === 'sellerApply' ? null : page} onSelect={selectTool} items={memberMenuItems.filter(item=>item!=='seller'||security.sellerApproved)} labels={memberMenuLabels} hrefs={memberPaths} counts={{ favorites: market.favorites.length, cart: market.cartCount }}/></div>
      <ProfileDropdown user={memberUser} secure={secure} sellerApproved={security.sellerApproved} page={page} busy={busy} onNavigate={goPage} onSignOut={onSignOut}/>
    </aside>
    <main className="member-panel">
      {page === 'dashboard' ? <><header className="member-heading"><div className="member-welcome"><span>{memberUser.displayName ? `สวัสดี ${memberUser.displayName}` : 'พื้นที่ของคุณ'}</span></div><h1>วันนี้จะค้นพบอะไรดี?</h1></header>
      <section className="member-discover" aria-label="สินค้าและงานสร้างสรรค์ที่คัดมาให้">
        <div className="member-deck" ref={deckRef} role="group" aria-roledescription="ชุดการ์ดสินค้า" aria-label="ใช้ลูกศรซ้ายขวา หรือเลือกการ์ดเพื่อเปลี่ยนสินค้า" onKeyDown={event => { if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') { event.preventDefault(); keyboardMove.current = true; shift(event.key === 'ArrowRight' ? 1 : -1); } }}>
          {featured.map((item, index) => {
            const distance = (index - active + featured.length + featured.length / 2) % featured.length - featured.length / 2;
            const current = index === active;
            return <motion.button ref={node => { cardRefs.current[index] = node; }} key={item.id} className={`member-card ${current ? 'is-current' : ''}`} style={{ width: cardWidth, marginLeft: -cardWidth / 2, zIndex: 20 - Math.abs(distance) }} initial={false}
              animate={{ x: distance * spacing, y: Math.abs(distance) * 5, scale: 1 - Math.abs(distance) * .055, opacity: 1 }}
              transition={reduce ? { duration: 0 } : { type: 'spring', stiffness: 260, damping: 30, mass: .9 }}
              aria-label={`${current ? 'ดูรายละเอียด' : 'เลือก'} ${item.title}`} tabIndex={current ? 0 : -1}
              onClick={() => { if (current) document.dispatchEvent(new CustomEvent('opencraft:open-product', { detail: { id: item.id } })); else setActive(index); }}
              drag={current && !reduce ? 'x' : false} dragConstraints={{ left: 0, right: 0 }} dragElastic={.18} dragSnapToOrigin
              onDragEnd={(_, info) => { if (Math.abs(info.offset.x) > 35 || Math.abs(info.velocity.x) > 350) shift(info.offset.x < 0 ? 1 : -1); }}>
              <span className="member-card-tag">{categoryNames[item.cat] || 'สินค้า'}</span>
              <img src={`/assets/${item.image}`} alt="" width="900" height="670" draggable={false}/>
              <span className="member-card-caption"><strong>{item.title}</strong><span>{item.type === 'service' ? 'เริ่ม ' : ''}฿{item.price.toLocaleString('th-TH')}</span></span>
            </motion.button>;
          })}
        </div>
        <div className="member-deck-controls"><button aria-label="สินค้าก่อนหน้า" onClick={() => shift(-1)}><ArrowLeft size={17}/></button><span aria-live="polite" aria-atomic="true">{active + 1} / {featured.length}</span><button aria-label="สินค้าถัดไป" onClick={() => shift(1)}><ArrowRight size={17}/></button></div>
        <p className="member-intro">ของดี ไอเดียใหม่ และงานสร้างสรรค์ที่คัดมาให้คุณ</p>
        <button className="member-browse" onClick={browse}>สำรวจสินค้าทั้งหมด<ArrowUpRight size={16}/></button>
        <p className="member-example">รายการสินค้าตัวอย่างของ OpenCraft</p>
      </section>
      <MemberCatalog preferredCategories={preferences?.interests}/></> : <MemberPages key={page} page={page} user={memberUser} authUser={authUser} preferences={preferences} busy={busy} showcase={showcase} security={security} onNavigate={goPage} onVerify={onVerify}/>}
      <footer className="member-hub-footer"><a href="/" onClick={event => { event.preventDefault(); navigateAuth('/'); }}>OpenCraft</a><div><a href="/sell">สมัครผู้ขาย</a><a href="/privacy">ความเป็นส่วนตัว</a><a href="/terms">ข้อกำหนด</a><a href="/contact">ติดต่อเรา</a></div></footer>
      {(notice || issue) && <div className={`member-notice ${issue ? 'is-error' : ''}`} role={issue ? 'alert' : 'status'}><span>{issue || notice}</span>{onDismiss && <button aria-label="ปิดข้อความ" onClick={onDismiss}><X size={16}/></button>}</div>}
    </main>
  </div>;
}
