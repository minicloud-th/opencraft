'use client';
import { useEffect, useRef, useState, type MouseEvent, type ReactNode } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { House, Bell, Settings, CircleHelp, ShieldCheck, Heart, ShoppingBag, Store, Wallet } from 'lucide-react';
import { cn } from '@/lib/utils';
import '@/animated-menu-bar.css';

export type MenuBarKey = 'dashboard' | 'favorites' | 'cart' | 'topup' | 'seller' | 'notifications' | 'settings' | 'help' | 'security';
export interface MenuBarProps {
  active?: MenuBarKey | null;
  onSelect?: (key: MenuBarKey) => void;
  labels?: Partial<Record<MenuBarKey, string>>;
  orientation?: 'horizontal' | 'vertical';
  items?: readonly MenuBarKey[];
  counts?: Partial<Record<MenuBarKey, number>>;
  hrefs?: Partial<Record<MenuBarKey, string>>;
  className?: string;
  'aria-label'?: string;
}
const menuItems: Record<MenuBarKey, { label: string; icon: ReactNode }> = {
  dashboard: { label: 'Dashboard', icon: <House size={22} strokeWidth={1.5}/> },
  favorites: { label: 'Saved items', icon: <Heart size={22} strokeWidth={1.5}/> },
  cart: { label: 'Cart', icon: <ShoppingBag size={22} strokeWidth={1.5}/> },
  topup: { label: 'Top up', icon: <Wallet size={22} strokeWidth={1.5}/> },
  seller: { label: 'Store', icon: <Store size={22} strokeWidth={1.5}/> },
  notifications: { label: 'Notifications', icon: <Bell size={22} strokeWidth={1.5}/> },
  settings: { label: 'Settings', icon: <Settings size={22} strokeWidth={1.5}/> },
  help: { label: 'Help', icon: <CircleHelp size={22} strokeWidth={1.5}/> },
  security: { label: 'Security', icon: <ShieldCheck size={22} strokeWidth={1.5}/> },
};
const defaultItems: readonly MenuBarKey[] = ['dashboard', 'notifications', 'settings', 'help', 'security'];
function IconButton({ itemKey, icon, label, active, vertical, href, count = 0, onClick }: { itemKey: MenuBarKey; icon: ReactNode; label: string; active: boolean; vertical: boolean; href?: string; count?: number; onClick: () => void }) {
  const [hovered, setHovered] = useState(false), [focused, setFocused] = useState(false), [tooltip, setTooltip] = useState(false);
  const timeout = useRef<number | null>(null);
  const reduce = useReducedMotion();
  const expanded = hovered || focused || (vertical ? tooltip : active);
  const Tag = href ? 'a' : 'button';
  useEffect(() => () => { if (timeout.current !== null) window.clearTimeout(timeout.current); }, []);
  return <Tag href={href} type={href ? undefined : 'button'} data-menu-key={itemKey} aria-label={count > 0 ? `${label} (${count})` : label} aria-current={href && active ? 'page' : undefined} aria-pressed={href ? undefined : active} className={cn('amb-button', active && 'is-active')} onPointerEnter={event => { if (event.pointerType !== 'touch') setHovered(true); }} onPointerLeave={() => setHovered(false)} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} onClick={(event: MouseEvent<HTMLAnchorElement | HTMLButtonElement>) => {
    if (href) { if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) return; event.preventDefault(); }
    if (matchMedia('(max-width: 639px)').matches) {
      setTooltip(true); if (timeout.current !== null) window.clearTimeout(timeout.current);
      timeout.current = window.setTimeout(() => setTooltip(false), 1200);
    }
    onClick();
  }}>
    <span className="amb-icon" aria-hidden="true">{icon}</span>
    {count > 0 && <span className="amb-count" aria-hidden="true">{count > 99 ? '99+' : count}</span>}
    <motion.span aria-hidden="true" className="amb-label-clip" initial={false} animate={{ width: expanded ? 'auto' : 0, opacity: expanded ? 1 : 0, marginLeft: expanded && !vertical ? 8 : 0 }} transition={reduce ? { duration: 0 } : { width: { type: 'spring', stiffness: 380, damping: 34 }, opacity: { duration: .18 }, marginLeft: { duration: .22 } }}><span>{label}</span></motion.span>
    {!vertical && <span className={cn('amb-tooltip', tooltip && 'is-visible')} aria-hidden="true">{label}</span>}
  </Tag>;
}
export function MenuBar({ active = 'dashboard', onSelect, labels, orientation = 'horizontal', items = defaultItems, counts, hrefs, className, 'aria-label': ariaLabel = 'เมนูพื้นที่สมาชิก' }: MenuBarProps) {
  return <nav className={cn('animated-menu-bar', orientation === 'vertical' && 'amb-vertical', className)} aria-label={ariaLabel}>
    {items.map((key, index) => <div key={key} className="amb-item">{index > 0 && key === 'notifications' && <span className="amb-divider" aria-hidden="true"/>}<IconButton itemKey={key} icon={menuItems[key].icon} label={labels?.[key] || menuItems[key].label} count={counts?.[key]} href={hrefs?.[key]} vertical={orientation === 'vertical'} active={active === key} onClick={() => onSelect?.(key)}/></div>)}
  </nav>;
}
export default MenuBar;
