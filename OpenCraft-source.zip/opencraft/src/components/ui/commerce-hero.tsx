'use client';
import { useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowUpRight, Search, Menu, ArrowRight, ShoppingBag, Code2, Gamepad2, PenTool } from 'lucide-react';
import { Sheet, SheetClose, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { navigateAuth } from '@/lib/auth-navigation';
import { GlassMarketplaceHero } from './glass-marketplace-hero';
import MemberCatalog from './member-catalog';
import AnimatedBackground from './animated-tabs';

const journeys = [
  { id: 'buy', label: 'ซื้อสินค้า', title: 'เริ่มจากของที่คุณชอบ', text: 'ค้นหาสินค้าและไฟล์ดิจิทัล เปรียบเทียบสิ่งที่ได้รับ แล้วเก็บรายการที่สนใจไว้ด้วยกัน', image: 'headphones.jpg', steps: ['ค้นหาหรือเลือกหมวดหมู่', 'ดูรายละเอียดและเงื่อนไข', 'บันทึกสิ่งที่สนใจไว้ในบัญชี'] },
  { id: 'hire', label: 'จ้างงาน', title: 'ให้คนถนัด ช่วยต่อยอดไอเดีย', text: 'งานออกแบบ เว็บไซต์ และบริการสร้างสรรค์ เริ่มด้วยการดูขอบเขตงานและสิ่งที่รวมอยู่ในแต่ละแพ็กเกจ', image: 'web-design.svg', steps: ['เลือกบริการที่ตรงกับงาน', 'อ่านขอบเขตและสิ่งที่ได้รับ', 'เตรียมรายละเอียดเพื่อคุยกับผู้ให้บริการ'] },
  { id: 'sell', label: 'เปิดร้าน', title: 'เปลี่ยนสิ่งที่ถนัด ให้คนค้นพบ', text: 'เตรียมชื่อร้าน หมวดหมู่ และคำอธิบายสินค้าไว้เป็นแบบร่าง ก่อนระบบร้านค้าเปิดให้ใช้งานจริง', image: 'brand-design.svg', steps: ['สร้างบัญชีและเลือกรูปแบบการใช้งาน', 'เตรียมสินค้าและรายละเอียดร้าน', 'บันทึกแบบร่างจากเมนูร้านค้า'] },
];
const directions = [
  { name: 'สินค้าดิจิทัล', description: 'Source Code, เทมเพลต และเครื่องมือสำหรับนักพัฒนา', icon: Code2 },
  { name: 'บริการสร้างสรรค์', description: 'เว็บไซต์ ออกแบบ ตัดต่อ และงานเฉพาะทาง', icon: PenTool },
  { name: 'สินค้าในชีวิตประจำวัน', description: 'อุปกรณ์ทำงาน ของใช้ และสินค้าจากร้านต่าง ๆ', icon: ShoppingBag },
  { name: 'เกมและชุมชน', description: 'ทิศทางหมวดเกมและกลุ่มความสนใจในอนาคต', icon: Gamepad2 },
];
const phases = [
  { title: 'เริ่มต้นในไทย', status: 'อยู่ระหว่างพัฒนา', text: 'เริ่มจากการค้นหาสินค้าและบริการดิจิทัล ระบบสมาชิก และพื้นที่สำหรับผู้ซื้อกับผู้ขาย' },
  { title: 'ขยายร้านค้าและบริการ', status: 'วางแผน', text: 'ระบบลงสินค้า คำสั่งซื้อ รีวิว แพ็กเกจผู้ขาย และหน้าร้าน Storefront โดยจะประกาศเงื่อนไขก่อนเปิดใช้จริง' },
  { title: 'เชื่อมระบบให้ครบขึ้น', status: 'วางแผน', text: 'ผู้ซื้อโพสต์หาสินค้า ชุมชนตามความสนใจ OpenCraft Custom และผู้ช่วยค้นหา AI รวมถึงศึกษาระบบชำระเงิน การจ่ายผู้ขาย และ Protect' },
  { title: 'เปิดรับโอกาสทั่วโลก', status: 'ระยะต่อไป', text: 'หลายภาษาและหลายสกุลเงิน เมื่อระบบร้านค้า การดูแลผู้ใช้ และการดำเนินงานพร้อมรองรับ' },
];
function jumpToSearch() { document.querySelector('#discover')?.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' }); document.querySelector<HTMLInputElement>('#public-catalog input[type=search]')?.focus({ preventScroll: true }); }
export function CommerceHero() {
  const [journey, setJourney] = useState('buy');
  const reduce = useReducedMotion();
  const selected = journeys.find(item => item.id === journey)!;
  return <div className="landing-site">
    <header className="site-header landing-header"><div className="nav-wrap">
      <a href="#experience" className="landing-brand" aria-label="OpenCraft หน้าแรก"><svg viewBox="220 170 1645 330" role="img" aria-label="OpenCraft"><image href="/assets/opencraft-wordmark.png" width="2048" height="682"/></svg></a>
      <nav className="landing-nav" aria-label="เมนูหน้าแรก"><a href="#discover">ค้นพบ</a><a href="#how-it-works">ใช้งานอย่างไร</a><a href="#sell">สำหรับผู้ขาย</a></nav>
      <div className="landing-header-actions"><button className="landing-search-button" onClick={jumpToSearch} aria-label="ค้นหาสินค้าก่อนสมัคร"><Search size={19}/></button><Button className="landing-login" onClick={() => navigateAuth('/dashboard')}>เข้าสู่ระบบ</Button>
      <Sheet><SheetTrigger asChild><button className="landing-mobile-menu" aria-label="เปิดเมนู"><Menu size={22}/></button></SheetTrigger><SheetContent className="portfolio-sheet" side="right"><SheetHeader><SheetTitle>OpenCraft</SheetTitle><SheetDescription>ทุกสิ่งที่มองหา มาเจอกันที่นี่</SheetDescription></SheetHeader><nav className="landing-mobile-links" aria-label="เมนูมือถือ"><SheetClose asChild><a href="#discover">ค้นหาสินค้า</a></SheetClose><SheetClose asChild><a href="#how-it-works">ใช้งานอย่างไร</a></SheetClose><SheetClose asChild><a href="#sell">สำหรับผู้ขาย</a></SheetClose><SheetClose asChild><button onClick={() => navigateAuth('/dashboard')}>เข้าสู่ระบบ</button></SheetClose></nav></SheetContent></Sheet>
      </div>
    </div></header>
    <GlassMarketplaceHero onDiscover={jumpToSearch}/>
    <div className="landing-content">
      <section className="landing-introduction"><h2>หนึ่งพื้นที่<br/>หลายความเป็นไปได้</h2><div><p>ซื้อของที่ชอบ หาคนช่วยทำงาน<br/>หรือเริ่มต้นร้านจากสิ่งที่คุณถนัด</p><span>One Marketplace. Endless Possibilities.</span></div></section>
      <div id="discover"><MemberCatalog publicView/></div>
      <section className="landing-directions" aria-labelledby="directions-title"><div className="landing-section-heading"><h2 id="directions-title">พื้นที่ของทุกความถนัด</h2><p>เริ่มจากสิ่งใกล้ตัว แล้วค่อยขยายไปด้วยกัน</p></div><div className="landing-direction-list">{directions.map(item => <div key={item.name}><item.icon size={24}/><h3>{item.name}</h3><p>{item.description}</p></div>)}</div></section>
      <section className="landing-journeys" id="how-it-works" aria-labelledby="journeys-title"><div className="landing-section-heading"><h2 id="journeys-title">อยากเริ่มแบบไหน?</h2><div className="landing-journey-tabs" role="tablist" aria-label="วิธีเริ่มใช้งาน" onKeyDown={event => { if (['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(event.key)) { event.preventDefault(); const nodes = [...event.currentTarget.querySelectorAll<HTMLButtonElement>('[role=tab]')]; const current = nodes.indexOf(document.activeElement as HTMLButtonElement); const next = event.key === 'Home' ? 0 : event.key === 'End' ? nodes.length - 1 : (current + (event.key === 'ArrowRight' ? 1 : -1) + nodes.length) % nodes.length; nodes[next]?.click(); nodes[next]?.focus(); } }}><AnimatedBackground value={journey} onValueChange={id => { if (id) setJourney(id); }} className="landing-tab-background" transition={{ type: 'spring', bounce: .15, duration: .35 }}>{journeys.map(item => <button key={item.id} data-id={item.id} id={`journey-tab-${item.id}`} role="tab" aria-controls="journey-panel" tabIndex={journey === item.id ? 0 : -1}>{item.label}</button>)}</AnimatedBackground></div></div>
        <div className="landing-journey-body" role="tabpanel" id="journey-panel" aria-labelledby={`journey-tab-${journey}`} tabIndex={0}><motion.img key={selected.image} src={`/assets/${selected.image}`} alt={selected.label} width="900" height="670" initial={reduce ? false : { opacity: 0, filter: 'blur(7px)' }} animate={{ opacity: 1, filter: 'blur(0px)' }} transition={{ duration: .4 }}/><div><h3>{selected.title}</h3><p>{selected.text}</p><ol>{selected.steps.map(step => <li key={step}>{step}</li>)}</ol><button className="landing-text-action" onClick={() => selected.id === 'sell' ? navigateAuth('/signup') : jumpToSearch()}>{selected.id === 'sell' ? 'เตรียมร้านของคุณ' : 'เริ่มสำรวจ'}<ArrowRight size={16}/></button></div></div>
      </section>
      <section className="landing-seller" id="sell"><div><h2>ของดีของคุณ<br/>ควรมีคนได้เห็น</h2><p>ไม่ว่าจะเป็นไฟล์ที่คุณสร้าง งานที่คุณถนัด<br/>หรือสินค้าที่ตั้งใจเลือกมา เริ่มเตรียมร้านของคุณได้ที่นี่</p><Button className="landing-dark-button" onClick={() => navigateAuth('/sell')}>สมัครผู้ขาย<ArrowUpRight size={16}/></Button><small>ระบบร้านค้าและแพ็กเกจผู้ขายอยู่ระหว่างพัฒนา</small></div><img src="/assets/desk.jpg" alt="มุมทำงานสำหรับคนสร้างสรรค์" width="900" height="670" loading="lazy"/></section>
      <section className="landing-future" aria-labelledby="future-title"><div className="landing-section-heading"><h2 id="future-title">จากจุดเริ่มต้น<br/>สู่ตลาดที่ครบขึ้น</h2><p>ทิศทางของ OpenCraft<br/>ฟีเจอร์ในแผนจะทยอยพัฒนาเมื่อพร้อม</p></div><div className="landing-phase-list">{phases.map((phase, index) => <details key={phase.title} open={index === 0}><summary><span><small>Phase {index + 1}</small>{phase.title}</span><em>{phase.status}</em></summary><p>{phase.text}</p></details>)}</div></section>
      <section className="landing-faq" aria-labelledby="faq-title"><h2 id="faq-title">ก่อนเริ่ม มีอะไรควรรู้?</h2><div><details><summary>ต้องสมัครก่อนค้นหาสินค้าไหม?</summary><p>ค้นหา เลือกหมวดหมู่ และดูรายละเอียดรายการได้ก่อนสมัคร เมื่ออยากใช้พื้นที่สมาชิกจึงค่อยสร้างบัญชีหรือเข้าสู่ระบบ</p></details><details><summary>ตอนนี้ซื้อหรือจ้างงานได้จริงหรือยัง?</summary><p>รายการสินค้า ราคา และร้านบนหน้านี้เป็นตัวอย่างเพื่อทดลองประสบการณ์ ยังไม่เปิดรับคำสั่งซื้อหรือชำระเงินจริง ส่วนแบบร่างร้านและตะกร้าถูกเก็บในเบราว์เซอร์นี้</p></details><details><summary>มีแพ็กเกจหรือค่าธรรมเนียมผู้ขายเท่าไร?</summary><p>ยังไม่มีการเรียกเก็บเงินหรือประกาศอัตรา Starter, Pro และ Studio เป็นแนวคิดที่ต้องทดสอบกับผู้ขายและประเมินต้นทุนก่อนเปิดใช้จริง</p></details><details><summary>Verified กับ Protect เปิดใช้แล้วหรือยัง?</summary><p>ป้ายในบัญชีปัจจุบันแสดงการยืนยันอีเมล ส่วนการตรวจสอบตัวตนร้านค้า OpenCraft Verified และการคุ้มครองซื้อขาย OpenCraft Protect อยู่ในแผน ยังไม่ใช่บริการที่เปิดใช้แล้ว</p></details><details><summary>หมวดเกมจะรองรับอะไรบ้าง?</summary><p>หมวดเกมและชุมชนเป็นทิศทางในอนาคต รายการที่เปิดให้ขายจะต้องผ่านการตรวจสอบกติกา สิทธิ์การจำหน่าย และเงื่อนไขของแต่ละเกมก่อน</p></details></div></section>
      <section className="landing-invitation"><h2>ความเป็นไปได้ใหม่<br/>เริ่มที่สิ่งที่คุณมองหา</h2><Button className="landing-dark-button" onClick={jumpToSearch}>ค้นพบสินค้าและบริการ<ArrowUpRight size={17}/></Button></section>
      <footer className="landing-footer"><div><strong>opencraft</strong><p>ตลาดซื้อขายสินค้าและบริการ ครบจบในที่เดียว</p></div><div><button data-info="about">เกี่ยวกับ OpenCraft</button><button data-info="fees">ค่าธรรมเนียม</button><button data-info="privacy">ความเป็นส่วนตัว</button><button data-info="terms">ข้อกำหนด</button></div><span>© {new Date().getFullYear()} OpenCraft</span></footer>
    </div>
  </div>;
}
export default CommerceHero;
