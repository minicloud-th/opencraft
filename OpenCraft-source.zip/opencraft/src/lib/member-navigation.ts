export const memberPaths = {
  dashboard: '/dashboard',
  favorites: '/dashboard/saved',
  cart: '/dashboard/cart',
  topup: '/dashboard/topup',
  seller: '/dashboard/store',
  notifications: '/dashboard/notifications',
  help: '/dashboard/help',
  security: '/dashboard/security',
  account: '/account',
  profile: '/dashboard/profile',
  sellerApply: '/dashboard/seller-apply',
} as const;

export type MemberPage = keyof typeof memberPaths;
export type MemberPath = (typeof memberPaths)[MemberPage];

export const memberTitles: Record<MemberPage, string> = {
  dashboard: 'หน้าหลัก', favorites: 'รายการที่บันทึก', cart: 'ตะกร้า', topup: 'เติมเงิน',
  seller: 'ร้านค้าของฉัน', notifications: 'การแจ้งเตือน', help: 'ช่วยเหลือ',
  security: 'ความปลอดภัย', account: 'ตั้งค่าบัญชี', profile: 'โปรไฟล์ของฉัน',sellerApply:'สมัครผู้ขาย',
};

export function getMemberPage(path: string): MemberPage | undefined {
  return (Object.keys(memberPaths) as MemberPage[]).find(page => memberPaths[page] === path);
}
