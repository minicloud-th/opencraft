import { useEffect, useState } from "react";
export type Theme = "light" | "dark";
const KEY = "opencraft-theme";
function readTheme(): Theme {
  try { return localStorage.getItem(KEY) === "dark" ? "dark" : "light"; } catch { return "light"; }
}
if (typeof document !== "undefined") {
  const initialTheme = readTheme();
  document.documentElement.dataset.theme = initialTheme;
  document.documentElement.classList.toggle("dark", initialTheme === "dark");
}
export function applyTheme(theme: Theme) {
  document.documentElement.dataset.theme = theme;
  document.documentElement.classList.toggle("dark", theme === "dark");
  try { localStorage.setItem(KEY, theme); } catch {}
  window.dispatchEvent(new CustomEvent("opencraft:theme", { detail: theme }));
}
export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => typeof window === "undefined" ? "light" : readTheme());
  useEffect(() => {
    applyTheme(theme);
    const update = (event: Event) => {
      const candidate = (event as CustomEvent<Theme>).detail;
      if (candidate === "light" || candidate === "dark") setTheme(candidate);
    };
    const storage = (event: StorageEvent) => { if (event.key === KEY) setTheme(event.newValue === "dark" ? "dark" : "light"); };
    window.addEventListener("opencraft:theme", update);
    window.addEventListener("storage", storage);
    return () => { window.removeEventListener("opencraft:theme", update); window.removeEventListener("storage", storage); };
  }, [theme]);
  return { theme, setTheme: applyTheme };
}
