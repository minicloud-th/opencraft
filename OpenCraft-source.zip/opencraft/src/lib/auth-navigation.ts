import type { MemberPath } from './member-navigation';

export function navigateAuth(path: MemberPath | '/' | '/#discover' | '/signup' | '/login' | '/reset-password' | '/dashboard#discover' | '/welcome' | '/privacy' | '/terms' | '/seller-terms' | '/legal/guardians' | '/sell' | '/contact') {
  history.pushState(null, '', path);
  dispatchEvent(new PopStateEvent('popstate'));
  window.scrollTo({ top: 0, behavior: 'instant' });
}
