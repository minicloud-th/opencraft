// Owner-private, stateless API smoke test. Send the service credential on hidden stdin only.
import assert from 'node:assert/strict';
if (process.stdin.isTTY) process.stdin.setRawMode(true);
process.stdout.write('Ready for private Site smoke-test JSON on stdin (input is hidden).\n');
let input = '';
const settings = await new Promise((resolve, reject) => {
  process.stdin.setEncoding('utf8');
  const read = chunk => {
    if (chunk.includes('\u0003')) { reject(new Error('cancelled')); return; }
    input += chunk;
    if (!input.includes('\n')) return;
    process.stdin.off('data', read); process.stdin.pause();
    if (process.stdin.isTTY) process.stdin.setRawMode(false);
    try { resolve(JSON.parse(input.trim())); } catch { reject(new Error('invalid-input')); }
  };
  process.stdin.on('data', read); process.stdin.resume();
});
try {
  // This credential may only be sent to this project's exact, verified Site origin.
  const origin = 'https://opencraft-market.kawertyff-2.chatgpt.site';
  if (settings.origin !== origin || typeof settings.token !== 'string' || !settings.token) throw new Error('invalid-input');
  const invoke = async (path, body) => {
    const response = await fetch(origin + path, { method: body ? 'POST' : 'GET', redirect: 'error', headers: { 'OAI-Sites-Authorization': `Bearer ${settings.token}`, ...(body ? { Origin: origin, 'Content-Type': 'application/json' } : {}) }, ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(20000) });
    return { status: response.status, data: await response.json() };
  };
  const health = await invoke('/api/runtime');
  assert.equal(health.status, 200); assert.equal(health.data.api, 'Go'); assert.equal(health.data.engine, 'Rust/Wasm'); assert.equal(health.data.engineCheck, 258000);
  const catalog = await invoke('/api/catalog?q=' + encodeURIComponent('หูฟัง'));
  assert.equal(catalog.status, 200); assert.deepEqual(catalog.data.products.map(p => p.id), ['headphones']);
  const quote = await invoke('/api/quote', { items: [{ id: 'headphones', quantity: 2 }] });
  assert.equal(quote.status, 200); assert.equal(quote.data.totalSatang, 258000); assert.equal(quote.data.checkoutEnabled, false);
  const topup = await invoke('/api/topup/preview', { amount: '42.29', method: 'promptpay' });
  assert.equal(topup.status, 200); assert.equal(topup.data.amountSatang, 4229); assert.equal(topup.data.paymentsEnabled, false);
  const profile = await invoke('/api/profile');
  assert.equal(profile.status, 401);
  const memberProfile = await invoke('/api/member-profile');
  assert.equal(memberProfile.status, 401);
  for(const path of ['/api/agreements','/api/seller-application','/api/support']) assert.equal((await invoke(path)).status,401);
  console.log(JSON.stringify({ production: 'passed', api: health.data.api, engine: health.data.engine, catalog: 'passed', quote: 'passed', topupPreview: 'passed', profileAuthorization: 'passed', memberShowcaseAuthorization: 'passed' }));
} catch {
  console.error('Production API smoke test failed. No service credential was printed.');
  process.exitCode = 1;
}
